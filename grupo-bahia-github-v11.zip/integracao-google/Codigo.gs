/**
 * GRUPO BAHIA IMÓVEIS — Servidor do site (Google Apps Script)
 * ------------------------------------------------------------
 * Este código roda no Google (não fica visível no site) e cuida de:
 *  - Mensagens do chat/contato  -> planilha "Contatos" + aviso no WhatsApp (CallMeBot)
 *  - Painel administrativo      -> login, usuários, postagens, fotos e vídeos
 *  - Postagens públicas         -> lidas pela página Imóveis do site
 *
 * PROPRIEDADES DO SCRIPT (Configurações do projeto > Propriedades do script):
 *   SENHA_INICIAL_DONO = senha inicial do dono (usada só uma vez, depois é apagada)
 *   WHATSAPP_NUMERO    = 5571996020606        (opcional, avisos do chat)
 *   CALLMEBOT_APIKEY   = chave do CallMeBot   (opcional, avisos do chat)
 *   EMAIL_AVISO        = e-mail               (opcional, cópia dos contatos)
 *
 * Dono: usuário "igor" (Igor Ribeiro). Só o dono autoriza, bloqueia e cria acessos.
 */

const DONO = { usuario: 'igor', nome: 'Igor Ribeiro' };
const SESSAO_SEG = 6 * 60 * 60;          // 6 horas
const MAX_TENTATIVAS = 5;                 // tentativas de login antes de bloquear por 15 min
const TIPOS_MIDIA = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'video/mp4', 'video/quicktime', 'video/webm'];

const ABAS = {
  Usuarios: ['id', 'usuario', 'nome', 'papel', 'status', 'salt', 'hash', 'criado', 'ultimoAcesso'],
  Posts:    ['id', 'tipo', 'titulo', 'categoria', 'cidade', 'resumo', 'etiqueta', 'preco', 'descricao', 'distancias', 'localTexto', 'mapa', 'ficha', 'situacao', 'formato', 'midias', 'status', 'destaque', 'ordem', 'autor', 'criado', 'atualizado'],
  Log:      ['data', 'usuario', 'acao', 'detalhe'],
  Contatos: ['Data', 'Nome', 'WhatsApp', 'Mensagem', 'Página', 'Chamar no WhatsApp']
};

/* ================= ENTRADAS ================= */

function doGet(e) {
  const acao = (e && e.parameter && e.parameter.acao) || 'posts';
  if (acao === 'posts') return json({ ok: true, posts: postsPublicos() });
  return json({ ok: true, servico: 'Grupo Bahia Imóveis' });
}

function doPost(e) {
  let d = {};
  try { d = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (_) {}
  try {
    preparar();
    const acao = d.acao || 'contato';
    const publicas = { contato, posts: () => ({ posts: postsPublicos() }), login, solicitarAcesso };
    if (publicas[acao]) return json(Object.assign({ ok: true }, publicas[acao](d) || {}));

    const eu = usuarioDaSessao(d.token);
    if (!eu) return json({ ok: false, erro: 'Sessão expirada. Entre novamente.', sair: true });

    const logadas = { me, logout, painel, postsAdmin, salvarPost, excluirPost, statusPost, moverPost, enviarMidia, trocarSenha };
    const doDono = { usuarios, criarUsuario, aprovarUsuario, bloquearUsuario, excluirUsuario, redefinirSenha, alterarPapel, registro };
    if (logadas[acao]) return json(Object.assign({ ok: true }, logadas[acao](d, eu) || {}));
    if (doDono[acao]) {
      if (eu.papel !== 'dono') throw new Error('Somente o dono pode fazer isso.');
      return json(Object.assign({ ok: true }, doDono[acao](d, eu) || {}));
    }
    throw new Error('Ação desconhecida.');
  } catch (err) {
    return json({ ok: false, erro: String(err.message || err) });
  }
}

/* ================= CONTATO (chat do site) ================= */

function contato(d) {
  const nome = limpar(d.nome, 60), tel = limpar(d.telefone, 20), msg = limpar(d.mensagem, 800), pagina = limpar(d.pagina, 40);
  const dig = tel.replace(/\D/g, '');
  if (nome.length < 2 || (dig.length !== 10 && dig.length !== 11) || msg.length < 2) throw new Error('Dados inválidos.');
  const responder = 'https://wa.me/55' + dig;
  aba('Contatos').appendRow([agora(), nome, tel, msg, pagina, responder].map(seguro));
  const texto = '🏡 *Novo contato pelo site*\n*Nome:* ' + nome + '\n*WhatsApp:* ' + tel + '\n*Página:* ' + pagina + '\n\n' + msg + '\n\nResponder: ' + responder;
  const p = PropertiesService.getScriptProperties();
  if (p.getProperty('WHATSAPP_NUMERO') && p.getProperty('CALLMEBOT_APIKEY')) {
    UrlFetchApp.fetch('https://api.callmebot.com/whatsapp.php?phone=' + p.getProperty('WHATSAPP_NUMERO') +
      '&text=' + encodeURIComponent(texto) + '&apikey=' + p.getProperty('CALLMEBOT_APIKEY'), { muteHttpExceptions: true });
  }
  if (p.getProperty('EMAIL_AVISO')) MailApp.sendEmail(p.getProperty('EMAIL_AVISO'), 'Novo contato pelo site: ' + nome, texto.replace(/\*/g, ''));
}

/* ================= ACESSO ================= */

function login(d) {
  const usuario = limpar(d.usuario, 40).toLowerCase(), senha = String(d.senha || '');
  const cache = CacheService.getScriptCache(), chave = 'f_' + usuario;
  const falhas = Number(cache.get(chave) || 0);
  if (falhas >= MAX_TENTATIVAS) throw new Error('Muitas tentativas. Aguarde 15 minutos.');
  const u = linhas('Usuarios').find(x => x.usuario === usuario);
  if (!u || hash(senha, u.salt) !== u.hash) {
    cache.put(chave, String(falhas + 1), 900);
    throw new Error('Usuário ou senha incorretos.');
  }
  if (u.status === 'pendente') throw new Error('Seu acesso ainda não foi autorizado pelo dono.');
  if (u.status !== 'ativo') throw new Error('Seu acesso está bloqueado.');
  cache.remove(chave);
  const token = Utilities.getUuid() + Utilities.getUuid();
  cache.put('s_' + token, u.id, SESSAO_SEG);
  atualizar('Usuarios', u.id, { ultimoAcesso: agora() });
  log(u.usuario, 'login', '');
  return { token, usuario: publicoUsuario(u) };
}

function solicitarAcesso(d) {
  const nome = limpar(d.nome, 60), usuario = limpar(d.usuario, 40).toLowerCase(), senha = String(d.senha || '');
  validarNovoUsuario(nome, usuario, senha);
  novoUsuario(nome, usuario, senha, 'editor', 'pendente');
  log(usuario, 'solicitou acesso', nome);
  return { mensagem: 'Pedido enviado. Aguarde a autorização do dono.' };
}

function me(d, eu) { return { usuario: publicoUsuario(eu) }; }
function logout(d, eu) { CacheService.getScriptCache().remove('s_' + d.token); log(eu.usuario, 'saiu', ''); }

function trocarSenha(d, eu) {
  if (hash(String(d.atual || ''), eu.salt) !== eu.hash) throw new Error('Senha atual incorreta.');
  validarSenha(String(d.nova || ''));
  const salt = Utilities.getUuid();
  atualizar('Usuarios', eu.id, { salt, hash: hash(String(d.nova), salt) });
  log(eu.usuario, 'trocou a senha', '');
}

/* ================= USUÁRIOS (só o dono) ================= */

function usuarios() { return { usuarios: linhas('Usuarios').map(publicoUsuario) }; }

function criarUsuario(d, eu) {
  const nome = limpar(d.nome, 60), usuario = limpar(d.usuario, 40).toLowerCase(), senha = String(d.senha || '');
  validarNovoUsuario(nome, usuario, senha);
  novoUsuario(nome, usuario, senha, d.papel === 'dono' ? 'dono' : 'editor', 'ativo');
  log(eu.usuario, 'criou usuário', usuario);
}
function aprovarUsuario(d, eu) { const u = alvo(d.id, eu); atualizar('Usuarios', u.id, { status: 'ativo' }); log(eu.usuario, 'autorizou', u.usuario); }
function bloquearUsuario(d, eu) { const u = alvo(d.id, eu); atualizar('Usuarios', u.id, { status: 'bloqueado' }); log(eu.usuario, 'bloqueou', u.usuario); }
function excluirUsuario(d, eu) { const u = alvo(d.id, eu); apagarLinha('Usuarios', u.id); log(eu.usuario, 'excluiu usuário', u.usuario); }
function alterarPapel(d, eu) { const u = alvo(d.id, eu); atualizar('Usuarios', u.id, { papel: d.papel === 'dono' ? 'dono' : 'editor' }); log(eu.usuario, 'alterou papel', u.usuario + ' → ' + d.papel); }
function redefinirSenha(d, eu) {
  const u = alvo(d.id, eu, true); validarSenha(String(d.senha || ''));
  const salt = Utilities.getUuid();
  atualizar('Usuarios', u.id, { salt, hash: hash(String(d.senha), salt) });
  log(eu.usuario, 'redefiniu senha', u.usuario);
}
function registro() { return { registro: linhas('Log').slice(-300).reverse() }; }

function alvo(id, eu, permitirProprio) {
  const u = linhas('Usuarios').find(x => x.id === id);
  if (!u) throw new Error('Usuário não encontrado.');
  if (!permitirProprio && u.id === eu.id) throw new Error('Você não pode alterar o seu próprio acesso por aqui.');
  if (u.usuario === DONO.usuario && eu.usuario !== DONO.usuario) throw new Error('O acesso do Igor Ribeiro não pode ser alterado.');
  return u;
}

/* ================= POSTAGENS ================= */

function postsPublicos() {
  return ordenar(linhas('Posts').filter(p => p.status === 'publicado')).map(p => {
    const o = formatarPost(p); delete o.autor; return o;
  });
}
function postsAdmin() { return { posts: ordenar(linhas('Posts')).map(formatarPost) }; }

function painel() {
  const posts = linhas('Posts'), us = linhas('Usuarios');
  return {
    total: posts.length,
    publicados: posts.filter(p => p.status === 'publicado').length,
    rascunhos: posts.filter(p => p.status !== 'publicado').length,
    pendentes: us.filter(u => u.status === 'pendente').length,
    contatos: Math.max(aba('Contatos').getLastRow() - 1, 0)
  };
}

function salvarPost(d, eu) {
  const p = d.post || {};
  const titulo = limpar(p.titulo, 120);
  if (titulo.length < 2) throw new Error('Informe um título.');
  let midias = Array.isArray(p.midias) ? p.midias.slice(0, 30) : [];
  midias = midias.map(m => ({ tipo: limpar(m.tipo, 10), id: limpar(m.id, 80), url: limpar(m.url, 500) })).filter(m => m.url || m.id);
  const dados = {
    tipo: ['divulgacao', 'lancamento'].indexOf(p.tipo) >= 0 ? p.tipo : 'imovel',
    situacao: ['reservado', 'vendido'].indexOf(p.situacao) >= 0 ? p.situacao : 'disponivel',
    formato: p.formato === 'largo' ? 'largo' : 'padrao',
    ficha: JSON.stringify((Array.isArray(p.ficha) ? p.ficha : []).slice(0, 16)
      .map(x => ({ rotulo: limpar(x.rotulo, 40), valor: limpar(x.valor, 80) })).filter(x => x.rotulo && x.valor)),
    titulo, categoria: limpar(p.categoria, 40), cidade: limpar(p.cidade, 100),
    resumo: limpar(p.resumo, 160), etiqueta: limpar(p.etiqueta, 40),
    preco: limpar(p.preco, 40), descricao: limpar(p.descricao, 6000), mapa: limpar(p.mapa, 300),
    distancias: JSON.stringify((Array.isArray(p.distancias) ? p.distancias : []).slice(0, 6)
      .map(x => ({ local: limpar(x.local, 40), km: limpar(x.km, 10), dir: ['N', 'NE', 'L', 'SE', 'S', 'SO', 'O', 'NO'].indexOf(x.dir) >= 0 ? x.dir : '' })).filter(x => x.local && x.km)),
    localTexto: limpar(p.localTexto, 400),
    midias: JSON.stringify(midias), status: p.status === 'publicado' ? 'publicado' : 'rascunho',
    destaque: p.destaque ? 'sim' : '', atualizado: agora()
  };
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    if (p.id && linhas('Posts').some(x => x.id === p.id)) {
      atualizar('Posts', p.id, dados); log(eu.usuario, 'editou postagem', titulo); return { id: p.id };
    }
    const id = 'p' + Date.now().toString(36);
    const ordem = linhas('Posts').reduce((m, x) => Math.min(m, Number(x.ordem) || 0), 0) - 1;
    inserir('Posts', Object.assign(dados, { id, ordem, autor: eu.nome, criado: agora() }));
    log(eu.usuario, 'criou postagem', titulo); return { id };
  } finally { lock.releaseLock(); }
}

function excluirPost(d, eu) {
  const p = linhas('Posts').find(x => x.id === d.id); if (!p) throw new Error('Postagem não encontrada.');
  if (d.apagarArquivos) {
    JSON.parse(p.midias || '[]').forEach(m => { if (m.id && m.tipo !== 'youtube') try { DriveApp.getFileById(m.id).setTrashed(true); } catch (_) {} });
  }
  apagarLinha('Posts', p.id); log(eu.usuario, 'excluiu postagem', p.titulo);
}
function statusPost(d, eu) {
  const p = linhas('Posts').find(x => x.id === d.id); if (!p) throw new Error('Postagem não encontrada.');
  const novo = {};
  if (d.status) novo.status = d.status === 'publicado' ? 'publicado' : 'rascunho';
  if (typeof d.destaque === 'boolean') novo.destaque = d.destaque ? 'sim' : '';
  atualizar('Posts', p.id, novo); log(eu.usuario, 'alterou postagem', p.titulo + ' ' + JSON.stringify(novo));
}
function moverPost(d, eu) {
  const lista = ordenar(linhas('Posts')); const i = lista.findIndex(x => x.id === d.id);
  const j = i + (d.direcao === 'cima' ? -1 : 1);
  if (i < 0 || j < 0 || j >= lista.length) return;
  [lista[i], lista[j]] = [lista[j], lista[i]];
  lista.forEach((p, k) => { if (Number(p.ordem) !== k) atualizar('Posts', p.id, { ordem: k }); });
  log(eu.usuario, 'reordenou', lista[j].titulo);
}

function enviarMidia(d, eu) {
  const mime = String(d.mime || ''); if (TIPOS_MIDIA.indexOf(mime) < 0) throw new Error('Formato não aceito: ' + mime);
  const blob = Utilities.newBlob(Utilities.base64Decode(String(d.base64 || '')), mime, limpar(d.nome, 100) || 'arquivo');
  const arq = pasta().createFile(blob);
  arq.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  const id = arq.getId(), video = mime.indexOf('video') === 0;
  log(eu.usuario, 'enviou arquivo', arq.getName());
  return { midia: { tipo: video ? 'video' : 'imagem', id, url: video ? 'https://drive.google.com/file/d/' + id + '/preview' : 'https://drive.google.com/thumbnail?id=' + id + '&sz=w1600' } };
}

/* ================= AUXILIARES ================= */

function preparar() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(ABAS).forEach(n => {
    let a = ss.getSheetByName(n);
    if (!a) { a = ss.insertSheet(n); a.appendRow(ABAS[n]); a.setFrozenRows(1); }
  });
  const props = PropertiesService.getScriptProperties();
  const inicial = props.getProperty('SENHA_INICIAL_DONO');
  if (inicial && !linhas('Usuarios').some(u => u.usuario === DONO.usuario)) {
    novoUsuario(DONO.nome, DONO.usuario, inicial, 'dono', 'ativo');
    props.deleteProperty('SENHA_INICIAL_DONO');
    log(DONO.usuario, 'conta do dono criada', '');
  }
}
/** Rode esta função uma vez pelo editor (botão Executar) para criar a conta do dono e as abas. */
function configurarDono() { preparar(); }

function usuarioDaSessao(token) {
  if (!token) return null;
  const id = CacheService.getScriptCache().get('s_' + token); if (!id) return null;
  const u = linhas('Usuarios').find(x => x.id === id);
  return u && u.status === 'ativo' ? u : null;
}
function novoUsuario(nome, usuario, senha, papel, status) {
  const lock = LockService.getScriptLock(); lock.waitLock(20000);
  try {
    if (linhas('Usuarios').some(u => u.usuario === usuario)) throw new Error('Esse usuário já existe.');
    const salt = Utilities.getUuid();
    inserir('Usuarios', { id: 'u' + Date.now().toString(36), usuario, nome, papel, status, salt, hash: hash(senha, salt), criado: agora(), ultimoAcesso: '' });
  } finally { lock.releaseLock(); }
}
function validarNovoUsuario(nome, usuario, senha) {
  if (nome.length < 3) throw new Error('Informe o nome completo.');
  if (!/^[a-z0-9._-]{3,30}$/.test(usuario)) throw new Error('Usuário: 3 a 30 letras minúsculas, números, ponto, hífen ou _.');
  validarSenha(senha);
}
function validarSenha(s) {
  if (s.length < 8 || !/[A-Za-z]/.test(s) || !/\d/.test(s)) throw new Error('A senha precisa de 8+ caracteres, com letras e números.');
}
function hash(senha, salt) {
  let h = salt + '|' + senha;
  for (let i = 0; i < 1500; i++) h = Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h + salt, Utilities.Charset.UTF_8));
  return h;
}
function publicoUsuario(u) { return { id: u.id, usuario: u.usuario, nome: u.nome, papel: u.papel, status: u.status, criado: u.criado, ultimoAcesso: u.ultimoAcesso, protegido: u.usuario === DONO.usuario }; }
function formatarPost(p) {
  let m = [], ds = [], fi = []; try { m = JSON.parse(p.midias || '[]'); } catch (_) {} try { ds = JSON.parse(p.distancias || '[]'); } catch (_) {} try { fi = JSON.parse(p.ficha || '[]'); } catch (_) {}
  return { id: p.id, tipo: p.tipo, titulo: p.titulo, categoria: p.categoria, cidade: p.cidade, resumo: p.resumo, etiqueta: p.etiqueta, preco: p.preco, descricao: p.descricao, distancias: ds, localTexto: p.localTexto, mapa: p.mapa, ficha: fi, situacao: p.situacao || 'disponivel', formato: p.formato || 'padrao', midias: m, status: p.status, destaque: p.destaque === 'sim', ordem: Number(p.ordem) || 0, autor: p.autor, criado: p.criado, atualizado: p.atualizado };
}
function ordenar(l) { return l.sort((a, b) => (Number(a.ordem) || 0) - (Number(b.ordem) || 0)); }
function pasta() {
  const p = PropertiesService.getScriptProperties(); const id = p.getProperty('PASTA_ID');
  if (id) try { return DriveApp.getFolderById(id); } catch (_) {}
  const f = DriveApp.createFolder('Grupo Bahia Imóveis - Mídias do site'); p.setProperty('PASTA_ID', f.getId()); return f;
}
function aba(n) { return SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n); }
function linhas(n) {
  const v = aba(n).getDataRange().getValues(); const cab = v.shift() || [];
  return v.map((r, i) => { const o = { _linha: i + 2 }; cab.forEach((c, j) => o[c] = r[j] instanceof Date ? Utilities.formatDate(r[j], 'America/Bahia', 'dd/MM/yyyy HH:mm') : String(r[j])); return o; });
}
// Evita que textos começando com = + - @ virem fórmula na planilha
function seguro(v) { return typeof v === 'string' && /^[=+\-@]/.test(v) ? "'" + v : v; }
function inserir(n, o) { aba(n).appendRow(ABAS[n].map(c => seguro(o[c] !== undefined ? o[c] : ''))); }
function atualizar(n, id, mud) {
  const a = aba(n), l = linhas(n).find(x => x.id === id); if (!l) return;
  Object.keys(mud).forEach(c => { const j = ABAS[n].indexOf(c); if (j >= 0) a.getRange(l._linha, j + 1).setValue(seguro(mud[c])); });
}
function apagarLinha(n, id) { const l = linhas(n).find(x => x.id === id); if (l) aba(n).deleteRow(l._linha); }
function log(usuario, acao, detalhe) { aba('Log').appendRow([agora(), usuario, acao, limpar(detalhe, 300)].map(seguro)); }
function agora() { return Utilities.formatDate(new Date(), 'America/Bahia', 'dd/MM/yyyy HH:mm'); }
function limpar(v, max) { return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B-\u001F]/g, '').trim().slice(0, max); }
function json(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
