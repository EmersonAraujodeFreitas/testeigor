/* =====================================================
   Grupo Bahia Imóveis — configuração do site e do painel
   ===================================================== */
window.CONFIG = {
  // WhatsApp da empresa (só números, com 55 + DDD)
  whatsapp: '5571996020606',

  // Endereço do "App da Web" do Google Apps Script (termina em /exec). Veja o LEIA-ME.txt (Passo 4).
  // Com ele preenchido:
  //  - o chat envia as mensagens direto, sem sair do site;
  //  - o painel administrativo (admin.html) funciona com login, usuários e postagens reais;
  //  - a página Imóveis mostra as postagens publicadas no painel.
  // Vazio: o chat abre o WhatsApp com a mensagem pronta e o painel roda em MODO DEMONSTRAÇÃO
  // (tudo fica só no navegador de quem está testando, nada é publicado).
  endpoint: ''
};
